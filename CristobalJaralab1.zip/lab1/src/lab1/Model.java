package lab1;

/**
 * 
 * @author jara
 *
 */
public class Model {
	/**
	 * Is the input for the first name
	 * 
	 */
	private String firstName;
	/**
	 * Is the input for the last name
	 * 
	 */
	private String lastName;
	/**
	 * Is the input for the height
	 * 
	 */
	private int height;
	/**
	 * Is the input for the weight
	 * 
	 */
	private double weight;
	/**
	 * Is to confirm if the model canTravel or not
	 * 
	 */
	private boolean canTravel;
	/**
	 * Is to confirm if the model smokes or not
	 * 
	 */
	private boolean smokes;
	/**
	 * 
	 * Set the occupation of the model
	 */
	private static String occupation = "modeling";
	/**
	 * 
	 * set the measurement to convert kgs to pounds
	 */
	public static final double KILOGRAMS_TO_POUNDS = 2.20462;
	/**
	 * 
	 * Set the measurement to convert inches to feet
	 */
	public static final int INCHES_PER_FOOT = 12;
	/**
	 * 
	 * Set the base rate dollars per hour
	 */
	public static final int BASE_RATE_DOLLARS_PER_HOUR = 60;
	/**
	 * 
	 * Compares the height of the model in inches
	 */
	public static final int TALL_INCHES = 67;
	/**
	 * 
	 * Compares the weight of the model in pounds
	 */
	public static final double THIN_POUNDS = 140.0;
	/**
	 * 
	 * Indicates the amount of dollars that a model gets as a bonus if is tall and
	 * thin
	 */
	public static final int TALL_THIN_BONUS_DOLLARS_PER_HOUR = 5;
	/**
	 * 
	 * Indicates the amount of dollars that a model gets as a bonus if can travel
	 */
	public static final int TRAVEL_BONUS_DOLLARS_PER_HOUR = 4;
	/**
	 * 
	 * 
	 * Indicates the deduction in dollars if the model is a smoker
	 */
	public static final int SMOKER_DEDUCTION_DOLLARS_PER_HOUR = 10;
	/**
	 * 
	 * 
	 * Indicates the minumum length for first name
	 */
	public static final int MINIMUM_LENGTH_FOR_FIRST_NAME = 3;
	/**
	 * 
	 * 
	 * Indicates the maximum length
	 */
	public static final int MAXIMUM_LENGTH_FOR_FIRST_NAME = 20;
	/**
	 * 
	 * 
	 * Indicates the minimum height
	 */
	public static final int MINIMUM_HEIGHT = 24;
	/**
	 * 
	 * 
	 * Indicates the maximum height
	 */
	public static final int MAXIMUM_HEIGHT = 84;
	/**
	 * 
	 * 
	 * Indicates the minimum weight
	 */
	public static final int MINIMUM_WEIGHT = 80;
	/**
	 * 
	 * 
	 * Indicates the maximum weight
	 */
	public static final int MAXIMUM_WEIGHT = 280;

	/**
	 * 
	 * 
	 * It prints the information referred to the model
	 */
	@Override
	public String toString() {
		return "Model [firstName=" + firstName + ", lastName=" + lastName + ", height=" + height + ", weight=" + weight
				+ ", canTravel=" + canTravel + ", smokes=" + smokes + "]";
	}

	/**
	 * 
	 * 
	 * Setting the constructor
	 */
	public Model() {

	}

	/**
	 * 
	 * @param firstName (Is the input for the first name)
	 * @param lastName (Is the input for the last name)
	 * @param height (private String lastName)
	 * @param weight (Is the input for the weight)
	 * @param canTravel (Is to confirm if the model canTravel or not)
	 * @param smokes (Is to confirm if the model smokes or not)
	 */
	public Model(String firstName, String lastName, int height, int weight, boolean canTravel, boolean smokes) {

		setFirstName(firstName);
		setLastName(lastName);
		setHeight(height);
		setWeight(weight);
		setCanTravel(canTravel);
		setSmokes(smokes);

	}

	/**
	 * Setting the information for the model. CanTravel and Smokes default values
	 * 
	 * @param firstName (Is the input for the first name)
	 * @param lastName (Is the input for the last name)
	 * @param height (private String lastName)
	 * @param weight (Is the input for the weight)
	 */
	public Model(String firstName, String lastName, int height, int weight) {

		setFirstName(firstName);
		setLastName(lastName);
		setHeight(height);
		setWeight(weight);
		setCanTravel(true);
		setSmokes(false);

	}

	/**
	 * 
	 * It will assign first name with length parameters
	 * 
	 * @param firstName
	 * (Is the input for the first name)
	 */
	public void setFirstName(String firstName) {

		if (firstName.length() >= MINIMUM_LENGTH_FOR_FIRST_NAME
				&& firstName.length() <= MAXIMUM_LENGTH_FOR_FIRST_NAME) {

			this.firstName = firstName;

		}

	}

	/**
	 * 
	 * It will assign last name with length parameters
	 * 
	 * @param lastName
	 * (Is the input for the last name)
	 */
	public void setLastName(String lastName) {

		if (lastName.length() >= MINIMUM_LENGTH_FOR_FIRST_NAME && lastName.length() <= MAXIMUM_LENGTH_FOR_FIRST_NAME) {

			this.lastName = lastName;

		}
	}

	/**
	 * 
	 * It will set height with minimum and maximum height
	 * 
	 * @param height
	 * (a measurament to describe model's height)
	 */
	public final void setHeight(int height) {

		if (height >= MINIMUM_HEIGHT && height <= MAXIMUM_HEIGHT) {

			this.height = height;

		}
	}

	/**
	 * It will set height with feet and inches
	 * 
	 * @param feet
	 * (measurament to describe model's feet in the height)
	 * @param inches
	 * (measurament to describe model's inches in the height)
	 */
	public final void setHeight(int feet, int inches) {

		setHeight((feet * INCHES_PER_FOOT) + inches);
	}

	/**
	 * 
	 * It will set weight with minimum and maximum
	 * @param weight
	 * (measurament to describe model's weight)
	 */
	public void setWeight(double weight) {

		if (weight >= MINIMUM_WEIGHT && weight <= MAXIMUM_WEIGHT) {

			this.weight = weight;

		}
	}

	/**
	 * 
	 * It will assign weight converting kilograms to pounds
	 * @param kilograms
	 * (a measurament to describe model's kilogram)
	 */
	public final void setWeight(long kilograms) {

		setWeight(kilograms * KILOGRAMS_TO_POUNDS);

	}

	/**
	 * It will assign the value of the CanTravel instant variable
	 * @param canTravel (Is to confirm if the model canTravel or not)
	 */
	public void setCanTravel(boolean canTravel) {

		this.canTravel = canTravel;

	}

	/**
	 * 
	 * It will assign the value of the smokes instant variable
	 * @param smokes (Is to confirm if the model smokes or not)
	 */
	public void setSmokes(boolean smokes) {

		this.smokes = smokes;

	}

	/**
	 * 
	 * Returns First Name of the model
	 * @return (It will return the first name of the model)
	 */
	public String getFirstName() {
		return this.firstName;
	}

	/**
	 * 
	 * Returns  Last Name of the model
	 * @return (It will return the last name of the model)
	 */
	public String getLastName() {
		return this.lastName;
	}

	/**
	 * 
	 * Returns  Height of the model
	 * @return (It will return the height of the model)
	 */
	public int getHeight() {
		return this.height;
	}

	/**
	 * 
	 * Returns  Weight of the model
	 * @return (It will return the weight of the model)
	 */
	public double getWeight() {
		return this.weight;
	}

	/**
	 * 
	 * Returns if model Can Travel or not
	 * @return (It will return if the model can travel or not)
	 */
	public boolean getCanTravel() {
		return this.canTravel;
	}

	/**
	 * 
	 * Returns if model Smokes or not
	 * @return (It will return if the model smokes or not)
	 */
	public boolean getSmokes() {
		return this.smokes;
	}

	/**
	 * 
	 * Returns model's Occupation
	 * @return (It will return model's occupation)
	 */
	public static String getOccupation() {

		return occupation;
	}

	/**
	 * 
	 * Creating the process to get the height of the model
	 * @return height using feet and inches, considering singular and plurals, depending of the situation
	 */
	public String getHeightInFeetAndInches() {

		int feet = this.height / INCHES_PER_FOOT;
		int inches = this.height % INCHES_PER_FOOT;
		if (inches == 1) {

			return feet + " feet 1 inch";
		}

		if (inches == 0) {

			return feet + " feet";

		}
		return feet + " feet " + inches + " inches";
	}

	/**
	 * 
	 * Creating the process to get model's weight in Kgs
	 * @return weight in Kgs from Model
	 */
	public long getWeightKg() {

		return Math.round(this.weight * KILOGRAMS_TO_POUNDS);
	}
	/**
	 * 
	 * It will print FirstName, LastName, Height and weight. Also It will return if the model does travel or not, or if the model does smoke or not.
	 * 
	 */
	public void printDetails() {
		System.out.println("Name: " + getFirstName() + " " + getLastName());
		System.out.println("Height: " + getHeightInFeetAndInches() + " inches");
		System.out.println(" Weight: " + Math.round(getWeight()) + " pounds");
		if (canTravel == true) {
			System.out.println("Does travel ");
		} else {
			System.out.println("Does not travel ");
		}
		if (smokes == true) {
			System.out.println("Does smoke ");
		} else {
			System.out.println("Does not smoke ");
		}
	}

	/**
	 * 
	 * It will calculate the salary per hour of the model considering three conditions
	 * 
	 * @return Return salary of the model including a bonus if is tall and thin, if
	 *         can travel or not or if is a smoker person or not
	 */
	public int calculatePayDollarsPerHour() {

		int salary = BASE_RATE_DOLLARS_PER_HOUR;

		if (getHeight() >= TALL_INCHES && getWeight() < THIN_POUNDS) {

			salary = salary + TALL_THIN_BONUS_DOLLARS_PER_HOUR;
		}

		if (getCanTravel()) {

			salary = salary + TRAVEL_BONUS_DOLLARS_PER_HOUR;
		}

		if (getSmokes()) {

			salary = salary - SMOKER_DEDUCTION_DOLLARS_PER_HOUR;
		}
		return salary;
	}
	/**
	 * It will print FirstName, LastName, Height and weight. And it will output if
	 * the model can travel or if it smokes, returning the payment in dollars
	 * considering those variables. The numeric values will use the numeric system by default.
	 */
	public void displayModelDetails() {

		displayModelDetails(false);

	}

	/**
	 * 
	 * It will print FirstName, LastName, Height and weight. And it will output if
	 * the model can travel or if it smokes, returning the payment in dollars
	 * considering those variables.
	 * 
	 * @param metricUnits true if the numeric values are using the metric system and false if theyre using imperial system
	 */
	public void displayModelDetails(boolean metricUnits) {

		System.out.println("Name: " + getFirstName() + " " + getLastName());

		if (metricUnits) {

			System.out.println("Height: " + getHeightInFeetAndInches());
			System.out.println("Weight: " + getWeight() + " pounds");

		}

		else {

			System.out.println("Height: " + Math.round(getHeight()));
			System.out.println("Weight: " + getWeightKg() + " kg");

		}

		System.out.println("Travels: " + (getCanTravel() ? "Yep" : "nope"));
		System.out.println("Smokes: " + (getSmokes() ? "Yep" : "nope"));
		System.out.println("Hourly rate: $" + calculatePayDollarsPerHour());

	}
}
