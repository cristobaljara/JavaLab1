package lab1;

public class Driver {

	public static void main(String[] args) {
		Model var = new Model();

		var.setFirstName("Cristobal");
		var.setLastName("Jara");
		var.setHeight(178);
		var.setWeight(74);
		var.setCanTravel(true);
		var.setSmokes(false);

		System.out.println(var);
		
		Model flow = new Model("Smil", "Ing", 167, 50, true, true);
		
		System.out.println(flow);
		
		Model flip = new Model("Jesus", "Mata", 187, 0);
		flip.setHeight(6, 4);
		flip.setWeight(100);
		System.out.println(flip);
		
		System.out.println("First Constructor firstname: " + var.getFirstName());
		System.out.println("First Constructor lastname: " + var.getLastName());
		System.out.println("First Constructor height: " + var.getHeight());
		System.out.println("First Constructor weight: " + var.getWeight());
		System.out.println("First Constructor CanTravel: " + var.getCanTravel());
		System.out.println("First Constructor Smokes: " + var.getSmokes());
		
		var.printDetails();
		
		System.out.println("Second Constructor firstname: " + flow.getFirstName());
		System.out.println("Second Constructor lastname: " + flow.getLastName());
		System.out.println("Second Constructor height: " + flow.getHeight());
		System.out.println("Second Constructor weight: " + flow.getWeight());
		System.out.println("Second Constructor CanTravel: " + flow.getCanTravel());
		System.out.println("Second Constructor Smokes: " + flow.getSmokes());
		
		flow.printDetails();
		
		System.out.println("Third Constructor firstname: " + flip.getFirstName());
		System.out.println("Third Constructor lastname: " + flip.getLastName());
		System.out.println("Third Constructor height: " + flip.getHeight());
		System.out.println("Third Constructor weight: " + flip.getWeight());
		System.out.println("Third Constructor CanTravel: " + flip.getCanTravel());
		System.out.println("Third Constructor Smokes: " + flip.getSmokes());
		
		flip.printDetails();
		
		
//		var.setHeight(int feet, inches);
//		var.setWeight(kilograms);
	}
}
